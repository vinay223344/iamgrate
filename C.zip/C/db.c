#include<stdio.h>
int isLeap(int year)
{
    return (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0));
}
int main()
{
	int date, month, year, res, i, oddDays=0;
	int marr[13] = {0,31,28,31,30,31,30,31,31,30,31,30,31}; // Odd days before beginning of each month
	printf("Enter date in the format, DD MM YYYY: ");
	scanf("%d %d %d", &date, &month, &year); // Read input date
	for(i = 1; i < year; i++)
	{
		if(isLeap(i))
		{
			oddDays += 1; // If year is leap, an extra odd day is added
		}
		oddDays += 1; // One odd day in an year
	}
	for(i = 0; i < month; i++)
	{
		if(i == 2 && isLeap(year)) // If month is February and it is leap year
			oddDays+=1; // An extra odd day is added
		oddDays+=marr[i]; // Odd days till the start of the present month is added to oddDays
	}
	oddDays += date; // Days in the present month are added to oddDays
	res = oddDays % 7; // Final odd days calculated
	printf("Day is ");
	switch(res) // Print day of the week based on the oddDay
	{
		case 0: printf("Sunday"); break;
		case 1: printf("Monday"); break;
		case 2: printf("Tuesday"); break;
		case 3: printf("Wednesday"); break;
		case 4: printf("Thursday"); break;
		case 5: printf("Friday"); break;
		case 6: printf("Saturday"); break;
	}
	printf("\n");
	return 0;
}
		
	
