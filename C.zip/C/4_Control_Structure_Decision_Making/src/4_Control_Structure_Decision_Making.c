/*
 ============================================================================
 Name        : 3_Control_Structure_Decision_Making.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include<stdio.h>

/* Program to print pattern:
A
A * B
A * B * C
A * B * C * D
A * B * C * D * E
 */
void p1()
{
	int n, i, j;
	printf("Enter no. of lines: ");
	scanf("%d" ,&n);
	for(i=1;i<=n;i++)
	{
		char c = 'A';
		for(j=1;j<=(2*i)-1;j++)
		{
			if(j%2 == 0)
			{
				printf("*"); // Print asterisk in even column
			}
			else
			{
				printf("%c",c++); // Print character in odd column and increment it
			}
		}
		printf("\n");
	}
}
/* Output: Enter no. of lines: 5
			A
			A * B
			A * B * C
			A * B * C * D
			A * B * C * D * E
*/

void p2()
{
	int n, i, j;
	printf("Enter no. of lines: ");
	scanf("%d", &n);
	char ch='A';
	for(i=n;i>0;i--)
	{
		if(i == n)
		{
			for(j=0;j<i;j++)
			{
				printf("%c ",ch);
			}
		}
		else
		{
			for(j=0;j<i;j++)
			{
				printf(" %c",ch);
			}
		}
		ch++;
		printf("\n");
	}
	ch--;
	for(i=1;i<n-1;i++)
	{
		ch--;
		for(j=0;j<=i;j++)
		{
			printf(" %c",ch);
		}
		printf("\n");
	}
}
/* Output: Enter no. of lines: 4
			A A A A
			 B B B
			 C C
			 D
			 C C
			 B B B
*/

//3.
void p3()
{
	int i;
	for(i=0;i<20;i++)
	{
		switch(i)
		{
		case 0: i+=5;
		case 1: i+=2;
		case 5: i+=5;
		default: i+=4;
		break;
		}
		printf("%d\n",i);
	}
}
/* Output:
    16
	21
*/
/*Explanation:
i=0:
	case 0: i=0+5 = 6
	case 1: i=6+2 = 8
	case 5: i=8+5 = 13
	default: i=13+4 = 16
i=17:
	default: i=17+4 = 21
*/

//4.
void p4()
{
	int a = 0, i = 0, b;
	for(i=0;i<5;i++)
	{
		printf("in loop: i=%d\n");
		a++;
		if(i==3) break;
	}
}
/* Output:
		in loop: i=4
		in loop: i=-1248300384
		in loop: i=-1248300384
		in loop: i=-1248300384
*/
/*Explanation: As no variable is given as an argument to printf corresponding to %d, the value at the top of the stack is printed.
 Now as the printf is called, the location is updated and other value is printed each time till the end of the loop.
*/

void p5()
{
	int i=0;
	do
	{
		i++;
		if(i==2)
			continue;
		printf("In while loop ");
	} while(i<2);
	printf("%d\n",i);
}
// Output: In while loop 2
/* Explanation: do -> i=1 -> print"In while loop" -> i<2=true -> i=2 -> continue -> i<2=false -> exit loop and print */


// 6. Program to print numbers between 1 and 500 that are divisible by 7 using goto.
void p6()
{
	int i = 1;
	sevenmultiple:
	if(i <= 500) // Checking if number is less than 500
	{
		if(i % 7 == 0) // Checking if it is multiple of 7
		{
			printf("%d ", i);
		}
		i++; // Incrementing it
		goto sevenmultiple; // goto the label 'sevenmultiple'
	}
}
/* Output: 7 14 21 28 35 42 49 56 63 70 77 84 91 98 105 112 119 126 133 140 147 154 161 168 175 182 189 196 203 210 217 224 231 238 245 252 259 266 273 280 287 294 301 308 315 322 329 336 343 350 357 364 371 378 385 392 399 406 413 420 427 434 441 448 455 462 469 476 483 490 497 */

// 7. Program to calculate the sum and average of 10 positive numbers using continue for skipping invalid input
void p7()
{
	int sum = 0, avg = 0, n, count = 0;
	printf("Enter 10 valid numbers each in a new line: \n");
	for(int i=0;i<10;i++)
	{
		scanf("%d", &n); // Read a number 'n'
		if(n < 0) // If number is not positive
		{
			continue; // Skip the current iteration and continue
		}
		else
		{
			count += 1;
			sum += n; // Add number to the sum
		}
	}
	avg = sum / count; // Calculate average
	printf("Sum = %d, Average = %d", sum, avg);
}
/* Output: Enter 10 valid numbers each in a new line:
1
2
3
4
5
-9
-6
-4
6
3
Sum = 24, Average = 2
*/

// 8. Program to input a number and a digit and find whether the digit is present in the number or not, if present, then count the number of times it occurs in the number?
void p8()
{
	int num, digit,cnt=0,d,n;
	printf("Enter number and digit: ");
	scanf("%d %d", &num, &digit);
	n = num;
	while(num>0)
	{
		d = num % 10; // Extract last digit
		if(d == digit) cnt++; // Check if last digit is equal to the given digit and increment count
		num /= 10; // Remove last digit
	}
	if(cnt!=0)
	{
		printf("Digit found and has occured %d time in %d", cnt, n); // Print the count of the digit in the number
	}
	else
	{
		printf("Digit not found"); // If digit is not found, display 'not found'
	}
}
/* Output: Enter number and digit: 14424254 4
	 	   Digit found and has occured 4 time in 14424254
*/

// 9. Program to set a Specific Bit of a number
void p9()
{
	int n, i,res;
	printf("Enter the number: ");
	scanf("%d", &n); // Read number
	printf("Enter bit to be set: ");
	scanf("%d", &i); // Read bit number to be set
	res = (1<<i) | n; // Leftshift 1 by the bit number and or it with the number
	// Ex. 1010 ==> to set 3rd bit, 0001 => 0100 | 1010 => 1110
	printf("Result: %d", res); // Print result
}
/*Output: Enter the number: 12
		  Enter bit to be set: 1
		  Result: 14
*/
/* Explanation: 12 -> 1100 -> 1110 -> 14*/

// 10. Program to clear a Specific Bit of a number
void p10()
{
	int n, i,res;
	printf("Enter the number: ");
	scanf("%d", &n); // Read number
	printf("Enter bit to be cleared: ");
	scanf("%d", &i); // Read bit number to be set
	res = ~(1<<i) & n; // Leftshift 1 by the bit number, negate all bits and 'and' it with the number
	// Ex. 1010 ==> to clear 2nd bit, 0001 => 0100 => 1011 | 1000 => 8
	printf("Result: %d", res); // Print result
}
/* Output: Enter the number: 15
		   Enter bit to be set: 2
		   Result: 11
*/
/* Explanation: 15 -> 1111 -> 1011 -> 11 */

// 11. Program to toggle a Specific Bit of a number
void p11()
{
	int i, num,pos,res;
	printf("Enter number and bit to be toggled separated by space: ");
	scanf("%d %d", &num, &pos);
	for(i=0;i<sizeof(int)*8;i++)
	{
		res = (1<<pos) ^ num;
	}
	printf("%d", res);
}
/* Output: Enter number and bit to be toggled separated by space: 15 3
			7
*/
/*Explanation: 1111 -> 0111 -> 7 */

// 12. Program to set Specific Bit is Set or Clear(status of bit)
void p12()
{
	int num,pos,res, status;
	printf("Enter number and bit to be checked separated by space: ");
	scanf("%d %d", &num, &pos);
	res = (num>>pos) & 1; // Right shift bits by the position of the bit to be checked and & it with 1
	status = res == 1 ? 1 : 0;
	printf("%d", status);
}
/* Output: Enter number and bit to be checked separated by space: 12 2
           1
*/
/* Explanation: 1100 -> 2nd bit = 1 */

// 13. Program to count the Set Bits(1's) in an Integer
void p13()
{
	int i, n, cnt = 0;
	printf("Enter the number: ");
	scanf("%d", &n); // Read the number
	for(i = 0; i<sizeof(int)*8; i++)
	{
		cnt += (n>>i) & 1; // Right shift bits by the position of the bit to be checked and & it with 1 and add the result (1/0) to count
	}
	printf("Number of set bits in the number: %d", cnt);
}
/* Output: Enter the number: 30
Number of set bits in the number: 4
*/
/* Explanation: 30 = 16 + 8 + 4 + 2 */

// 14. Program to count the Clear Bits(0's) in an integer
void p14()
{
	int i, num, cnt = 0;
	printf("Enter the number: ");
	scanf("%d", &num); // Read the number
	for(i=0;i<sizeof(int)*8;i++)
	{
		cnt += (num>>i) & 1; // Right shift bits by the position of the bit to be checked and & it with 1 and add the result (1/0) to count
	}
	cnt = sizeof(int)*8 - cnt;
	printf("%d", cnt);
}
/* Output: Enter the number: 15
28
*/
/* Explanation: 15 -> 00000001 -> 30 0's */

// Main function
int main()
{
	int n;
	printf("Enter question number(1-14): ");
	scanf("%d", &n);
	switch(n)
	{
		case 1: p1(); break;
		case 2: p2(); break;
		case 3: p3(); break;
		case 4: p4(); break;
		case 5: p5(); break;
		case 6: p6(); break;
		case 7: p7(); break;
		case 8: p8(); break;
		case 9: p9(); break;
		case 10: p10(); break;
		case 11: p11(); break;
		case 12: p12(); break;
		case 13: p13(); break;
		case 14: p14(); break;
	}
	return 0;
}
