// Program to print multiples of 7 between 1 and 500 using goto
#include<stdio.h>
int main()
{
	int i = 1;
	sevenmultiple:
	if(i <= 500) // Checking if number is less than 500
	{
		if(i % 7 == 0) // Checking if it is multiple of 7
		{
			printf("%d ", i);
		}
		i++; // Incrementing it
		goto sevenmultiple; // goto the label 'sevenmultiple'
	}
	return 0;
}
