// Program to count clear bits in a number
#include<stdio.h>
int main()
{
	int i, num, cnt = 0;
	for(i=0;i<sizeof(int)*8;i++)
	{
		cnt += (n>>i) & 1;
	}
	cnt = sizeof(int)*8 - cnt;
	printf("%d", cnt);
	return 0;
}
