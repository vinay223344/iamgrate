// Program to count number of set bits in a number
#include<stdio.h>
int main()
{
	int i, n, cnt = 0;
	printf("Enter the number: ");
	scanf("%d", &n); // Read the number
	for(i = 0; i<sizeof(int)*8; i++)
	{
		cnt += (n>>i) & 1; // Shift number by 'i' times, if the last bit is 1, increase count
	}
	printf("Number of set bits in the number: %d", cnt);
	return 0;
}
