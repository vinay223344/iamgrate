// Program to print difference between two dates in days, months and years
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main()
{
	int d1, m1, y1, d2, m2, y2, days, months, years;
	int mon[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	printf("Enter first date(DD MM YYYY): ");
	scanf("%d %d %d", &d1, &m1, &y1);
	printf("Enter second date(DD MM YYYY): ");
	scanf("%d %d %d", &d2, &m2, &y2);
	
	//if(y1==y2 || (y1!=0 && m1==m2) || (y1!=0 && m1!=m2 && d1==d2)
	//{
		
	
	years = abs(y1-y2)-1;
	if (y1!=y2) {months = (m2-m1 <= 1) ? m2-m1 : (12 - m1) + m2-1;}
	else months = m2-m1;
	years = (y2-y1 <= 1 && m1==m2) ? y2-y1 : years;
	days = m1>=m2 ? abs(d2-d1) : (mon[m1-1]-d1 + d2);
	printf("%d years %d months %d days", years, months, days);
	if( days >= mon[m1-1])
	{
		days -= mon[m1-1];
		months += 1;
	}
	if(months >= 12 ) 
	{
		years += 1;
		months -= 12;
	}
	
	printf("%d years %d months %d days", years, months, days);
	return 0;
}
	
