// Program to toggle a specific bit in a number
#include<stdio.h>
int main()
{
	int i, num,pos,res;
	scanf("%d %d", &num, &pos);
	for(i=0;i<sizeof(int)*8;i++)
	{
		res = (1<<pos) ^ num;
	}
	printf("%d", res);
	return 0;
}
