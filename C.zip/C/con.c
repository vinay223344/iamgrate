// Program t calculate sum and average of 10 numbers using continue for skipping invalid input
#include<stdio.h>
int main()
{
	int i,sum = 0, avg = 0, n;
	for(i = 0; i < 10; i++)
	{
		scanf("%d", &n); // Read a number 'n'
		if(n < 0) // If number is not positive
		{
			continue; // SKip the current iteration and continue
		}
		else
		{	
			sum += n; // Add number to the sum
			avg = sum / (i+1); // Calculate average
		}
	}
	printf("Sum = %d, Average = %d", sum, avg);
	return 0;
}
		
