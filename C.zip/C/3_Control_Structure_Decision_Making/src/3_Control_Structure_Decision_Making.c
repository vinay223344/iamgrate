/*
 ============================================================================
 Name        : 3_Control_Structure_Decision_Making.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include<string.h>

// Function to check if a year is leap or not
int isLeap(int year)
{
	return (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0));
}

/* 1. Program to accept any number upto six digits and print each digit in words
   Ex: 1503 -> one five zero three
*/
void p1()
{
//	int n, num, rev=0, rem;
//	printf("Enter a number: ");
//	scanf("%d", &num);
//	n = num;
//	while(num > 0) // Reversing the given number
//	{
//		rem = num % 10; // Extract last digit
//		rev = rev * 10 + rem; // Move rev digits to one place left and add rem(last digit of number)
//		num = num / 10; // Drop the last digit
//	}
//	printf("The number %d can be read as: ", n);
//	while(rev > 0)
//	{
//		rem = rev % 10; // Extract last digit of rev( First bit of number)
//		switch(rem) // Print the digit in words
//		{
//			case 0: printf("zero "); break;
//			case 1: printf("one "); break;
//			case 2: printf("two "); break;
//			case 3: printf("three "); break;
//			case 4: printf("four "); break;
//			case 5: printf("five "); break;
//			case 6: printf("six "); break;
//			case 7: printf("seven "); break;
//			case 8: printf("eight "); break;
//			case 9: printf("nine "); break;
//		}
//		rev = rev / 10; // Drop the digit
//	}
	char num[6]="123456";
	int i;
	printf("Enter a six digit number: ");
	scanf("%s", num);
	for(i=0;i<strlen(num);i++)
	{
		switch(num[i])
		{
		case '0': printf("zero "); break;
		case '1': printf("one "); break;
		case '2': printf("two "); break;
		case '3': printf("three "); break;
		case '4': printf("four "); break;
		case '5': printf("five "); break;
		case '6': printf("six "); break;
		case '7': printf("seven "); break;
		case '8': printf("eight "); break;
		case '9': printf("nine "); break;
		}
	}
}
/* Output: Enter a number: 1503
   The number 1503 can be read as: one five zero three
*/

//2. Program to find day of a week for a given date
void p2()
{
	int date, month, year, res, i, oddDays=0;
	int marr[13] = {0,31,28,31,30,31,30,31,31,30,31,30,31}; // Odd days before beginning of each month
	printf("Enter date in the format, DD MM YYYY: ");
	scanf("%d %d %d", &date, &month, &year); // Read input date
	for(i = 1; i < year; i++)
	{
		if(isLeap(i))
		{
			oddDays += 1; // If year is leap, an extra odd day is added
		}
		oddDays += 1; // One odd day in an year
	}
	for(i = 0; i < month; i++)
	{
		if(i == 2 && isLeap(year)) // If month is February and it is leap year
			oddDays+=1; // An extra odd day is added
		oddDays+=marr[i]; // Odd days till the start of the present month is added to oddDays
	}
	oddDays += date; // Days in the present month are added to oddDays
	res = oddDays % 7; // Final odd days calculated
	printf("Day is ");
	switch(res) // Print day of the week based on the oddDay
	{
		case 0: printf("Sunday"); break;
		case 1: printf("Monday"); break;
		case 2: printf("Tuesday"); break;
		case 3: printf("Wednesday"); break;
		case 4: printf("Thursday"); break;
		case 5: printf("Friday"); break;
		case 6: printf("Saturday"); break;
	}
	printf("\n");
}
/* Output: Enter date in the format, DD MM YYYY: 04 02 2026
Day is Wednesday
*/

//3. Program to find out the number of 500, 100, 50, 20, 10, 5, 2, 1 Rupee notes can purchase for a given amount of money
void p3()
{
	int amount, n500, n100, n50, n20, n10, n5, n2, n1 ;
	printf("Enter the amount: ");
	scanf("%d", &amount);
	n500 = amount / 500; // No. of 500 rupee notes
	amount = amount % 500;   // Remaining amount
	n100 = amount / 100;
	amount = amount % 100;
	n50 = amount / 50;
	amount = amount % 50;
	n20 = amount / 20;
	amount = amount % 20;
	n10 = amount / 10;
	amount = amount % 10;
	n5 = amount / 5;
	amount = amount % 5;
	n2 = amount / 2;
	amount = amount % 2;
	n1 = amount / 1;
	amount = amount % 1;
	printf("No. of 500 Rupee notes: %d\n",n500);
	printf("No. of 100 Rupee notes: %d\n",n100);
	printf("No. of 50 Rupee notes: %d\n",n50);
	printf("No. of 20 Rupee notes: %d\n",n20);
	printf("No. of 10 Rupee notes: %d\n",n10);
	printf("No. of 5 Rupee notes: %d\n",n5);
	printf("No. of 2 Rupee notes: %d\n",n2);
	printf("No. of 1 Rupee notes: %d\n",n1);
}

// 4. Program to find the difference of two dates in years, months and dates
void p4()
{
	int d1, m1, y1, d2, m2, y2;
	int days, months, years;
	int mon[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

	printf("Enter first date (DD MM YYYY): ");
	scanf("%d %d %d", &d1, &m1, &y1);
	printf("Enter second date (DD MM YYYY): ");
	scanf("%d %d %d", &d2, &m2, &y2);

	// To handle the case where date-2 < date-1: Swap the dates
	if (y1 > y2 || (y1 == y2 && m1 > m2) || (y1 == y2 && m1 == m2 && d1 > d2))
	{
	    int t;
	    t = d1; d1 = d2; d2 = t;
	    t = m1; m1 = m2; m2 = t;
		t = y1; y1 = y2; y2 = t;
	}
	// Calculating dates
	if (d2 < d1)
	{
	    m2--;
	    if (m2 == 2 && isLeap(y2))
		days = d2 + 29 - d1;
	    else
		days = d2 + mon[m2 - 1] - d1;
	}
	else
	{
	    days = d2 - d1;
	}
	//Calculating months
	if (m2 < m1)
	{
		y2--;
		months = m2 + 12 - m1;
	}
	else
	{
	    months = m2 - m1;
	}
	years = y2 - y1;
	printf("%d years %d months %d days\n", years, months, days);
}

/* 5. Program to simulate a basic ATM:
      -> Check pin
      -> Show balance
      -> Allow withdrawal / deposit
      -> Exit
*/
void p5()
{
	int userPin, enteredPin, option, balance = 0, deposit, withdraw;
	printf("Enter a PIN to set: ");
	scanf("%d", &userPin);
	printf("Enter PIN: ");
    scanf("%d", &enteredPin);
    if(userPin == enteredPin)
    {
    	while(1)
    	{
    		printf("1. Show balance\n2. Withdraw\n3. Deposit\n4. Exit\nSelect an option: ");
    		scanf("%d", &option);
    		switch(option)
    		{
    		case 1: printf("Balance: %d", balance); break;
    		case 2:
    			printf("Enter amount to be withdrawn: ");
    			scanf("%d", &withdraw);
    			balance = balance - withdraw;
    			printf("Please collect your amount...\n");
    			printf("Balance: %d\n", balance);
    			break;
    		case 3:
    			printf("Enter amount to be deposited: ");
    			scanf("%d", &deposit);
    			balance = balance + deposit;
    			printf("Amount successfully deposited into your account\n");
    			printf("Balance: %d\n", balance);
    			break;
    		case 4: exit(1);
    		}
    	}
    }
    else
    {
    	printf("PIN doesn't match");
    }
}
/* Output: Enter a PIN to set: 1234
Enter PIN: 1234
1. Show balance
2. Withdraw
3. Deposit
4. Exit
Select an option: 3
Enter amount to be deposited: 10000
Amount successfully deposited into your account
Balance: 10000
1. Show balance
2. Withdraw
3. Deposit
4. Exit
Select an option: 2
Enter amount to be withdrawn: 1000
Please collect your amount...
Balance: 9000
1. Show balance
2. Withdraw
3. Deposit
4. Exit
Select an option: 4
*/

/* Program to classify age groups:
   -> 0-12: Child
   -> 13-19: Teenager
   -> 20-59: Adult
   -> 60+: Senior Citizen
 */
void p6()
{
	int age;
	printf("Enter age: ");
	scanf("%d", &age);
	if(age >= 0 && age <= 12)
	{
		printf("Child");
	}
	else if(age >= 13 && age <= 19)
	{
		printf("Teenager");
	}
	else if(age >= 20 && age <= 59)
	{
		printf("Adult");
	}
	else if(age >=60)
	{
		printf("Senior Citizen");
	}
}


// Main function
int main()
{
	int n;
	printf("Enter question number(1-6): ");
	scanf("%d", &n);
	switch(n)
	{
		case 1: p1(); break;
		case 2: p2(); break;
		case 3: p3(); break;
		case 4: p4(); break;
		case 5: p5(); break;
		case 6: p6(); break;
	}
	return 0;
}
