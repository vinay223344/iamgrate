#include <stdio.h>
int isLeap(int year)
{
    return (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0));
}
int main()
{
	int d1, m1, y1, d2, m2, y2;
	int days, months, years;
	int mon[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	printf("Enter first date (DD MM YYYY): ");
	scanf("%d %d %d", &d1, &m1, &y1);
	printf("Enter second date (DD MM YYYY): ");
	scanf("%d %d %d", &d2, &m2, &y2);
	if (y1 > y2 || (y1 == y2 && m1 > m2) || (y1 == y2 && m1 == m2 && d1 > d2))
	{
	    int t;
	    t = d1; d1 = d2; d2 = t;
	    t = m1; m1 = m2; m2 = t;
	    t = y1; y1 = y2; y2 = t;
	}
	if (d2 < d1)
	{
	    m2--;
	    if (m2 == 2 && isLeap(y2))
		days = d2 + 29 - d1;
	    else
		days = d2 + mon[m2 - 1] - d1;
	}
	else
	{
	    days = d2 - d1;
	}
	if (m2 < m1)
	{
	    y2--;
	    months = m2 + 12 - m1;
	}
	else
	{
	    months = m2 - m1;
	}
	years = y2 - y1;
	printf("%d years %d months %d days\n", years, months, days);
	return 0;
}

