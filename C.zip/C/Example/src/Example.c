/*
 ============================================================================
 Name        : Example.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
	int n=123;
	while(n>0)
	{
		int rem=n%10;
		int rev=rev*10+rem;
		n/=10;
	}
}
