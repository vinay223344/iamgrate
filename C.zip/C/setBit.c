// Program to set a bit of a number 
#include<stdio.h>
int main()
{
	int n, i,res;
	printf("Enter the number: ");
	scanf("%d", &n); // Read number
	printf("Enter bit to be set: ");
	scanf("%d", &i); // Read bit number to be set
	res = (1<<i) | n; // Leftshift 1 by the bit number and or it with the number
	// Ex. 1010 ==> to set 3rd bit, 0001 => 0100 | 1010 => 1110
	printf("Result: %d", res); // Print result
	return 0;
}
