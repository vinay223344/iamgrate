// Program to count occurences of a digit in a number
#include<stdio.h>
int main()
{
	int num, digit,cnt=0,d,n;
	printf("Enter number and digit: ");
	scanf("%d %d", &num, &digit);
	n = num;
	while(num>0)
	{
		d = num % 10;
		if(d == digit) cnt++;
		num /= 10;
	}
	if(cnt!=0)
	{
		printf("Digit found and has occured %d time in %d", cnt, n);
	}
	else
	{
		printf("Digit not found");
	}
	return 0;
}
