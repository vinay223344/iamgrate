// Program to print pattern
/* A  A  A  A  
    B  B  B  
    C  C  
    D
    C  C  
    B  B  B
*/

