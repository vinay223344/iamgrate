# This line is commented & will be ignored by the python compiler.
"""I want to write more descriptive comments for my python code but this may not
fit into a single line. So I want to write into multiple lines. For doing this I want to use 
one of the multi-line comments which is called triple-double quotes"""
'''Instead of using triple double-quotes as shown above, sometimes I feel like using 
triple-single quotes to write multi-line comments'''

'''I'm just curious to know If I can nest single line comments in multi-line and 
vice-versa, and single line comment in itself & multi-line comment in itself'''
# I'm adding one-more single line comment character .i.e., #in this line
# Adding triple-double quotes multi-line comment here."""
"""I don't know what to write here as I'm not sure how does the compiler treats this line.
I'm curious to know."""
#Adding triple-single quotes multi-line comments here.’’’ As previous lines gave
'''compilation errors, I'm expecting compilation errors even for this, but still 
I'm curious'''
"""Within triple double quotes I'm adding single line comment character # just to check if 
python compiler accepts this or not. I'm bit crazy so I'm adding one more # character.
"""
"""Within triple double quotes I'm adding one more""" '''just to check if I can nest''' """ inside
another"""
'''Within triple single quotes I'm adding one """just to check if I can nest """ inside 
'''
'''Within tripe double quotes I'm adding one more """ just to check if I can nest """ inside
another'''
