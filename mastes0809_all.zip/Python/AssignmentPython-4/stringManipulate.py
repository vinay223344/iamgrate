"""string1 = '''How do I write single string in multiple lines. Because in future 
I may manipulate very long strings'''
#string1[7]='u'
string1 = string1[0:7]+'u'+string1[8:]
print(string1)
string1 = string1[0:7]+string1[8:]
print(string1)
del string1
print(string1)"""

string1 = "Nothing between "+"you"+"I"
print(string1)
string1 = "How to add space between "+"you"+" "+"I"
print(string1)
string1 = "How to separate "+"you"+"\n"+"I"
print(string1)
string1 = 'butter'
string2 = "Betty bought some string1 \n but the string1 was bitter \n \
	 	   so she bought some better string1 \n to make bitter string1\n \
	 	   better"
print(string2)
string2 = "Betty bought some {string1} \n but the {string1} was bitter \n \
	 	   so she bought some better {string1} \n to make bitter {string1}\n \
	 	   better"
print(f"{string2}")
print(f"Betty bought some {string1} \n but the {string1} was bitter \n \
	 	   so she bought some better {string1} \n to make bitter {string1}\n \
	 	   better")
string2 = "Why do someone repeat any string 3 times"*3+" "+"But I'm repeating"
print(string2)
string2 = "Hi"*3
string2 = 3*"Hi"
string2 = "Hi"*"Hi"
