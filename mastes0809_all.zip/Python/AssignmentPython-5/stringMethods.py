string1 = "AllAreAlphabets"
print("The return value of string1.isalpha() = " ,string1.isalpha())
print(type(string1.isalpha()))
string1 = "123AreNotAlphabets.456AreAlsoNot"
print("The return value of string1.isalpha() = ", string1.isalpha())
print("The return value of string1[0:3].isdigit = ",string1[0:3].isdigit())
print("The return value of (string1[0:3]+string1[19:22]*4).isdigit() = ",(string1[0:3]+string1[19:22]*4).isdigit())
string1 = "There are 4 spaces in front of me"
print("The return value of string1[0:4].isspace() = ",string1[0:4].isspace())

string1 = "-2-10aBc\\n 123dEf"
print("The return value of string1.upper() = ",string1.upper())
print("The return value of string1.lower() = ",string1.lower())
print("The return value of string1.title() = ",string1.title())
print(type(string1.upper()))
print(type(string1.lower()))
print(type(string1.title()))

string1 = "Wh is the starting string for statements that ends with?"
print(string1.startswith("Wh"),type(string1.startswith("Wh")))
print(string1.startswith('W'),type(string1.startswith('W')))
#print(string1.startswith())
print(string1.startswith(string1[0:2].upper().lower().title()),type(string1.startswith(string1[0:2].upper().lower().title())))
#print(".startswith())

print(string1.endswith("?"),type(string1.endswith("?")))
print("endswith".endswith("endswith"),type("endswith".endswith("endswith")))
#print(".endswith())

string1 = "Who can separate IandYOU?"
print(string1.split('and'),type(string1.split('and')),len(string1.split('and')))
print(string1.split(),type(string1.split()),len(string1.split()))
print(string1.split('YO'),type(string1.split('YO')),len(string1.split('YO')))
string1 = "and"
print(string1.join(('I','YOU')))
#print("".join('I','YOU')) => join takes atmost one argument
print(string1.join(['I','YOU']))
#print("".join(((1),(2)))) => join takes atmost one argument
print('='.join(['2','Two']).endswith('Two'))
#print(''.join()) => join() takes one argument

print("0123456789".find('0'))
print("0123456789".find('1'))
print("0123456789".find('12'))
print("0123456789".find('567'))
print("0123456789".find('-1'))
print("can you find me?".find('yes'))
print("who can reach me?".find("me"))
#print("Nothing to find".find()) => find() takes atleast one argument
print("we had lunch".replace("lunch","launched"))
print("Nobody can replace me".replace('Nobody','Anybody').replace('Anybody','who').title())
print("I'm a good person".replace("good","bad").replace("I'm","You're"))
print("You can't replace me".replace('I','you'))
print("".replace("",'Empty'))
print("yyyyy".replace("",'o'))
#print("".replace("")) => replace() takes two arguments
#print(''.replace()) => replace() takes two arguments

print(" \n\n Spaces and new lines around me \n\n \n\n ".strip())
print(" \n\n Spaces and new lines around me \n\n \n\n ".rstrip())
print(" \n\n Spaces and new lines around me \n\n \n\n ".lstrip())
print(" \n\n Spaces and new lines around me \n\n \n\n ".strip('\n'))
print(" \n\n Spaces and new lines around me \n\n \n\n ".lstrip('\n'))
print("??QuestionMarksAroundMe??".strip())
print("??QuestionMarksAroundMe??".strip('?'))
print("??QuestionMarksAroundMe??".strip('Me??'))
