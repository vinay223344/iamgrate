#print("I","""Just""",'started','''understanding''','about',"functionality","of, print")
#print("I","""Just""",'started','''understanding''','about\n',"functionality","of,newline character,.i.e.\n")
#print("I'm","""learning""",'how to','''use escape character''','\\n',"usage")
#print("I","""Just""",'started','''understanding''',"""about\\n""",\
#"functionality"\
#,"of, print")
#print("I","""Just""",'started','''understanding''',"""about\\n,
#"functionality"
#of, print""")
print("How","to","add",'question',"""mark","character"\
,
\""at the end of line
""",
end="?")
#print("I want no space between I","you",sep=' ')
#print("what is there between I","you",sep='and',end='?')

