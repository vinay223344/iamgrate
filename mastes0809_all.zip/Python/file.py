variable = "Idhi python nerchukovadaniki raasina script"
printchey=1
print(printchey)
print(variable)
