var1 = 10
var_2 = 10.2
var3 = "String"
var4 = 'String'
_var5 = """I'm anonymous string.
I'm seated in three double quotes"""
_6var = '''I'm another anonymous string. My friend is seated in """ quotes but I'm seated in'''

_var7 = var1
_tuple = (var1, var_2,"Three",("Inner","tuple"))
_list = [(var3, var4),_var5,_tuple,_6var]
#print("Value of variable var1=",var1,"\n","Value of variable var_2=",var_2)
#print("The value of tuple _tuple",_tuple,sep='=')
#print("The value of list _list",_list,sep='=')

#print("Type of var1=",type(var1))
#print("Type of var_2=",type(var_2))
#print("Type of var3=",type(var3))
#print("Type of _var5=",type(_var5))
#print("Type of _6var=",type(_6var))
#print("Type of _tuple=",type(_tuple))
#print("Type of _list=",type(_list))
#print(print("print(print())"))
#print('print("print(print())")')
#print(type(print()))

#print("Value of varible 'var1'=",var1)

#print("Value of var_2=",var_2,"and after converting to integer=",int(var_2))
#print("Value of var1=",var1,"and after converting to float=",float(var1))
#print(int(var3))
#print(type(str(int(var_2))))
e=10.2
num1=e-10
#num2=10.4e-1
#print(int(e-num1)+int(num2))
#print(int(10.4e-1))
#str1 = "A" + "sentence"
#str2 = "doesn't"+"ends"*1+"with"
#str3 = "I'm of no use"*0 + "because"*3
#str4 = str1+str2+str3+"is a conjunction"  
#print(str4)
#print(len(str1))
#print(len(str2))
#print(len(str3))
#print(len(str4))
print("How to add number"+e+"with number"+num1, end='?\n')
print("How to add number"+str(e)+"with number"+str(num1), end='?\n')
print("The sum of two numbers"+str(e)+str(num1)+"="+str(e+num1))
print(f"The sum of two numbers {e} and {num1} is "+str(e+num1))

