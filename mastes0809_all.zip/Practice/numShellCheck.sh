#!/usr/bin/csh

set userNo=0

if ($#argv < 1) then
    echo "Please provide at least one user ID in the command line"
    echo "Example command : ./numShellCheck.sh userID1 userID2"
endif

foreach userID ($argv)
    @ userNo++
    set ttyID=`who | grep "$userID" | grep -Po "pts\S+"`
    echo "=============== USER ID = $userID ==============="
    echo "The no. of shells = $#ttyID"
    echo "The shell IDs = $ttyID"
end

