set currentShellProcessID = $argv[1]
	  set scriptProcessID = $$
	  if ($currentShellProcessID == $scriptProcessID)	then
	  	  echo “Script is executed in current shell”
	  else
	  	  echo “Script is executed in sub shell”
		  echo "parent shell="$currentShellProcessID
		  echo "sub shell="$scriptProcessID
	  endif 
