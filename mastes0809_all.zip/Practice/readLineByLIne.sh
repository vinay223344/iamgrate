#!/usr/bin/csh -f
if (! -e $argv[1]) then 
	echo "Error: File $argv[1] does not exist"
	exit 1
endif
set numLines=`wc -l < $argv[1]`
#echo $numLines
set currentLine=1
while ($currentLine <= $numLines)
	echo -n $currentLine
	tail --lines=+$currentLine $argv[1] | head -1
	@ currentLine = $currentLine + 1
end
