#!/usr/bin/csh
#Defining two variables in script.
set scriptLocalVar = “I’m local variable defined in script”
setenv scriptEnvVar “I’m environment variable defined in script”
#Checking the existance of current Shell Local variables
if ($?currentShellLocalVar) then
	echo "INFO :The variable currentShellLocalVar is accessible in process $0"
else
	echo "INFO :The variable currentShellLocalVar isn’t accessible in process $0" 
endif
#Checking the existance of current Shell Environment variables
if ($?currentShellEnvVar) then
	echo "INFO : The variable currentShellEnvVar is accessible in process $0"
else
	echo "INFO : The variable currentShellEnvVar isn’t accessible in process $0"
endif
