#! /usr/bin/csh-f
set dbDate = `date`
set dbDateDMY = "$dbDate[3]$dbDate[2]$dbDate[6]"
set dbName = $argv[1]_$dbDateDMY
echo $dbName
#checking if directory already exists .If yes , get permission from user whether to overwrite.If
#answer is “y” then create else exit normally.
if (-e $dbName) then
	echo "Data base '$dbName' already exists. Do you want to over-write ? Press y/n"
	set userPerm = $<
	if ($userPerm == "y") then
		rm -rf $dbName
		mkdir $dbName
		echo "New database directory is created : $dbName"
	else
		echo "Thank you \!\! Your existing Data base is safe"
	endif
else
	mkdir $dbName
	echo "New database directory is created : $dbName"
endif
