#! /usr/bin/csh-f
#Script to read data of a file, whose name provided through command line, line by line
#The list of user names
set group1 = (mastes0804 mastes0809)
set ttyIDs1 = (/dev/pts/201 /dev/pts/405)
set users =  (mastes0804 mastes0809 mastes0807 mastes0808 mastes0805)
echo "$users"
#The lists of groups
#The list of terminal IDs
set ttyIDs2 = (/dev/pts/201 /dev/pts/405 /dev/pts/320 /dev/pts/369 /dev/pts/186)
# Note : users & ttyIDs lists should have one to one mapping in their elements.
#Finding index of user in list users
if ( $#argv <= 0) then
	echo "Add atleast one argument" 
	exit
endif
if ($argv[1] == "group1") then
	set list = ($group1)
	set ttyIDs = ($ttyIDs1)
else if ($argv[1] == "all") then
	set list = ($users)
	set ttyIDs = ($ttyIDs2)
else
	set list = ($argv[1-])
	set ttyIDs = ($ttyIDs2)
endif
echo "Type message here...."
set message = ( $< )

foreach user ($list)
	set userIndex = 0
	set userFound = 0
	echo $user
	foreach curUser ($users)
		if ($curUser == $user) then
	       	@ userIndex = $userIndex + 1
			set userFound = 1
			break
		endif
		@ userIndex = $userIndex + 1
	end
	if ($userFound == 1) then
		echo "The user $user is found"
		echo "The current user Index is $userIndex"
	else
		echo "The user $user is not found"
	endif
	# Checking if the user has given write permissions
	if (! -e $ttyIDs[$userIndex] ) then
		echo "The user $user has not opened chat box"
		continue
	else if (! -w $ttyIDs[$userIndex]) then
		echo "The user $user has not enabled chat box"
		continue
	endif
	echo "Group Message from Mokshagna" >> $ttyIDs[$userIndex]
	echo "$message" >> $ttyIDs[$userIndex]
end
