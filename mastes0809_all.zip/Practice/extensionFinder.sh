#!bin/csh
find $argv[1] -name "*.txt" |xargs cp -t $argv[2]
find $argv[1] -name "*.sh" |xargs cp -t $argv[3]
find $argv[1] -name "*.csh" |xargs cp -t $argv[4]
find $argv[1] -name "*.ex" |xargs cp -t $argv[5]
