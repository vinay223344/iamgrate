#! /usr/bin/csh
# The purpose of this script is to check if script is executed in the current shell or sub-Shell
#Checking if no.of command line arguments are 1
set currentShellProcessID = $argv[1]
set scriptProcessID = $$
if ($currentShellProcessID == $scriptProcessID) then
	echo “Script is executed in current shell”
else
	echo “Script is executed in sub shell”
endif
