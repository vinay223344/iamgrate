# The purpose of this script is to check if script is executed in the current shell or sub-Shell
set currentShellProcessID = $argv[1]
set scriptProcessID = $$
if ($currentShellProcessID == $scriptProcessID) then
	echo “Script is executed in current shell”
else
	echo “Script is executed in sub shell”
endif
