#! /usr/bin/csh-f
#Script to read data of a file, whose name provided through command line, line by line
set user = $argv[1]
#The list of user names
set users =  (mastes0804 mastes0809 mastes0805)
echo "$users"
#The lists of groups
#The list of terminal IDs
set ttyIDs = (/dev/pts/201 /dev/pts/405 /dev/pts/186)
# Note : users & ttyIDs lists should have one to one mapping in their elements.
#Finding index of user in list users
set userIndex = 0
set userFound = 0
echo "$userFound"
foreach curUser ($users)
	if ($curUser == $user) then
		@ userIndex = $userIndex + 1
		set userFound = 1
		break
	endif
	@ userIndex = $userIndex + 1
end
if ($userFound == 1) then
	echo "The user $argv[1] is found"
	echo "The current user Index is $userIndex"
else
	echo "The user $argv[1] is not found"
endif
# Checking if the user has given write permissions
if (! -e $ttyIDs[$userIndex] ) then
	echo "The user $argv[1] has not opened chat box"
	exit
else if (! -w $ttyIDs[$userIndex]) then
	echo "The user $argv[1] has not enabled chat box"
	exit
endif
echo "Type message here...."
set message = ( $< )
echo "Message from mastes0809" >> $ttyIDs[$userIndex]
echo "$message" >> $ttyIDs[$userIndex]
