//Data types
//1. 
#include <stdio.h>
int main() {
    int a=4000,b=200,c=15; // Defining variables
    printf("a=%d\nb=%d\nc=%d\n",a,b,c);
    printf("%a=%4d\n%b=%4d\n%c=%4d",a,b,c);
    return 0;
}
/*Output: 	a=4000
			b=200
			c=15
			0x0p+0=4000
			%b= 200
			=   0
*/
//2.
#include<stdio.h>
int main()
{
	char mc='2'; // Defining a character variable
	printf("mc=%c %d\n",mc,mc); // %c-->character %d-->respective ASCII value
	mc=mc*2;
	printf("mc=%c %d\n",mc,mc);
	mc*=2;
	printf("mc=%c %d\n",mc,mc);
}
/*Output: 	mc=2 50
			mc=100d 
			mc=� -56
*/
//3
#include<stdio.h>
int main()
{
	short int s1=0,s2=0;
	unsigned short int u1=0, u2=0;
	printf("s1=%hd s2=%hd\n",s1,s2);
	printf("u1=%hd u2=%hd\n",u1,u2);
	s2=s1-1;
	u2=u1-1;
	printf("s1=%hd s2=%hd\n",s1,s2);
	printf("u1=%hd u2=%hd\n",u1,u2);
}
/*Output: 	s1=0 s2=0
			u1=0 u2=0
			s1=0 s2=-1
			u1=0 u2=-1
*/
//4.
#include<stdio.h>
int main()
{
	short int x=55,y=6;
	printf("x=%d y=%d\n",x,y);
	printf("Enter two integers:");
	scanf("%hd %hd",&x,&y);
	printf("x=%d y=%d\n",x,y);
}
/*Output: 	x=55 y=6
			Enter two integers:1 20
			x=1 y=20
*/
//5. 
#include<stdio.h>
int main()
{
	unsigned short int var=0;
	printf("var = %hu\n",var);
	--var;
	printf("var = %hu\n",var);
}
/*Output: 	var = 0
			var = 65535
*/
//6.
#include<stdio.h>
int main()
{
	unsigned int var=0;
	printf("var = %u\n",var);
	var=var-1;
	printf("var = %u\n",var);
}
/*Output: 	var = 0
			var = 4294967295
*/
//7.
#include<stdio.h>
int main()
{
	unsigned long int var=0;
	printf("var = %lu\n",var);
	var=var-1;
	printf("var = %lu\n",var);
}
/*Output: 	var = 0
			var = 18446744073709551615
*/
//8.
#include<stdio.h>
int main()
{
	int a=10;
	printf("a=%d\n",a);
	++a;
	printf("a=%d\n",a);
	a++;
	printf("a=%d\n",a);
	--a;
	printf("a=%d\n",a);
	a--;
	printf("a=%d\n",a);
}
/*Output: 	a=10
			a=11
			a=12
			a=11
			a=10
*/
//9.
#include<stdio.h>
int main()
{
	int x=10,y=0;
	int i=10,j=0;
	printf("x=%d y=%d\n",x,y);
	printf("i=%d j=%d\n",i,j);
	y=++x;
	j=i++;
	printf("x=%d y=%d\n",x,y);
	printf("i=%d j=%d\n",i,j);
}
/*Output: 	x=10 y=0
			i=10 j=0
			x=11 y=11
			i=11 j=10
*/
//10.
#include<stdio.h>
int main()
{
	float v=34.5;
	printf("v=%f\n",v);
	v=v/2;
	printf("v=%f\n",v);
}
/*Output: 	v=34.500000
			v=17.250000
*/
//11.
#include<stdio.h>
int main()
{
	float v=1234.5;
	printf("v=%e %f\n",v,v);
	v=v*100;
	printf("v=%e %f\n",v,v);
	v=3.4;
	printf("v=%e %f\n",v,v);
	v=0.000567;
	printf("v=%e %f\n",v,v);
}
/*Output: 	v=1.234500e+03 1234.500000
			v=1.234500e+05 123450.000000
			v=3.400000e+00 3.400000
			v=5.670000e-04 0.000567
*/
//12.
#include<stdio.h>
int main()
{
	int a=20,b=021,c=0x22;
	int d;
	d=a+b+c;
	printf("d=%d %o %x\n",d,d,d);
}
/*Output: 	d=71 107 47 */

//1. Program to print the size of the data types: int, float, char and double
#include<stdio.h>
int main()
{
	printf("Size of int: %d\n",sizeof(int));
	printf("Size of float: %d\n",sizeof(float));
	printf("Size of double: %d\n",sizeof(double));
	printf("Size of char: %d\n",sizeof(char));
}
/*Output: 	Size of int: 4
			Size of float: 4
			Size of double: 8
			Size of char: 1
*/

//2. Program to test if a given character is: Lowercase letter, Uppercase letter, Digit, Whitespace(space, tab, newline) operators
#include<stdio.h>
int main()
{
	char c;
	printf("Enter the character: ");
	scanf("%c", &c);
	if(c>='a' && c<='z')
	{
		printf("The character is a lowercase letter");
	}
	else if(c>='A' && c<='Z')
	{
		printf("The character is an uppercase letter");
	}
	else if(c>='0' && c<='9')
	{
		printf("The character is a digit");
	}
	else if(c==' ')
	{
		printf("The character is a space");
	}
	else if(c=='\t')
	{
		printf("The character is a tab space");
	}
	else
	{
		printf("The character is a new line");
	}
	return 0;
}
/*Output: 	Enter the character: R	
			The character is an uppercase letter
			Enter the character: u	
			The character is a lowercase letter
			Enter the character: 9
			The character is a digit
			Enter the character:  	
			The character is a space
			Enter the character: 		
			The character is a tab space
			Enter the character: 
			The character is a new line
*/

/*3. Compilation Process: It is the process of converting the program to a machine language.
	 a. Preprocessor
	 b. Compiler
	 c. Linker
	 d. Assembler*/

