//1.
#include <stdio.h>
int main() {
    int x=10,y=20,z=30;
	printf("%d %d %d\n",x,y,z);
	x=y=z=40; // z=40; y=z => y=40; x=y => x=40
	printf("%d %d %d\n",x,y,z);
}
/* Output: 10 20 30
		   40 40 40
*/

//2.
#include <stdio.h>
int main() {
    int x=10,y=20,z=30,result=-1;
	result=z>y>x;  //z>y=>1 | 1>10=>0
	printf("result = %d\n",result);
}
/* Output: result = 0 */

//3.
#include <stdio.h>
int main() {
    int i=20.5;
	float f=20.4;
	int result;
	result= i==f;  //20!=20.4
	printf("%d\n", result);
	result= i==(int)f; //20==20
	printf("%d\n", result);
	result= (float)i==f; //20.5!=20.4
	printf("%d\n", result);
	result=i<f; //20<20.4
	printf("%d\n", result);
	result=i<(int)f; //20.5!<20
	printf("%d\n", result);
}
/* Output: 0
		   1
		   0
		   1
		   0
*/

//4.
#include <stdio.h>
int main() {
    int a=5,b=0,c=-3,d=-1;
	printf("%d %d %d %d\n",a,b,c,d);
	d=a&&b; // 1 || 0 => 0
	printf("%d %d %d %d\n",a,b,c,d);
	d=b||c; // 0 || 1 => 1
	printf("%d %d %d %d\n",a,b,c,d);
	d=!a||!c; // 0 || 0 => 0
	printf("%d %d %d %d\n",a,b,c,d);
}
/* Output: 5 0 -3 -1
		   5 0 -3 0
	       5 0 -3 1
		   5 0 -3 0
*/

//5.
#include <stdio.h>
int main() {
    int a=5,b=0,c=-3,d=-1;
	printf("%d %d %d %d\n",a,b,c,d); // 5 0 3 -1
	d = ++a || ++b || ++c; // 6 || 1 || -3 => 1 || 1 || 1 => 1 (c will remain -3 as the first argument to 'or' is true, and hence the compiler doesn't check the second argument)
	printf("%d %d %d %d\n",a,b,c,d); // 6 1 -3 1
	a=5,b=0,c=-3,d=-1;
	d = b++ && c++ && a++; // 0 && -3 && 5 => 0 && 1 && 1 => 0
	printf("%d %d %d %d\n",a,b,c,d); // 5 1 -3 0
	a=5,b=0,c=-3,d=-1; 
	d = ++b && ++c && ++a; // 1 && -2 && 6 => 1 && 1 && 1 => 1
	printf("%d %d %d %d\n",a,b,c,d); // 6 1 -2 1
}
/* Output: 5 0 -3 -1
		   6 0 -3 1
		   5 1 -3 0
		   6 1 -2 1
*/

//6.
#include <stdio.h>
int main() {
    int result;
	char ch;
	printf("Enter a char:");
	scanf("%c", &ch);
	result = (ch>=65)&&(ch<=90);
	result = (((ch>='A')&&(ch<='Z')||(ch>='a')&&(ch<='z')));
	printf("%d",result);
}
/* Output: Enter a char:4
	       0
		   Enter a char:M
		   1
*/

//7.
#include <stdio.h>
int main() {
    unsigned char a;
	a = 0xFF + 1; // 255 + 1 = 256 => wraps around and equals to 0
	printf("%u\n",a);
}
/* Output: 0 */

//8. 
#include <stdio.h>
int main() {
    int x=10, y=20, z=5, i;
	i=x<y<z; // 10<20<5 => 1<5 => 1
	printf("%d\n",i);
}
/* Output: 1 */

//9.
#include <stdio.h>
int main() {
    unsigned int x=022, y=0x22, z=022;
	printf("%d",x+y+z); // 18+34+18 = 70
}
/* Output: 70 */

//10.
#include <stdio.h>
int main() {
    int a=123, b=456;
	a^=b^=a^=b;  // a=a^b; b=b^a; a=a^b ==> Swaps a and b
	printf("%d %d",a,b);
}
/* Output: 456 123 */

//11.
#include <stdio.h>
int main() {
    int a=10,b;
	b=a>5?100:200; // 10>5=>true => 100
	printf("%d",b);
}
/* Output: 100 */

//12.
#include <stdio.h>
int main() {
    printf("%d\n",-1<<4); // 1111 << 4 => 11110000 => -128+64+32+16 => -16
	printf("%d\n",-1>>2); // 1111 >> 2 => 1111 => -1
	printf("%x\n",1<<10); // 0001 << 10 => 10000000000 => 400
	printf("%x\n",0xFF<<4); // 11111111 << 4 => 111111110000 => FF0
	printf("%o\n",034<<2); // 000011100 << 2 => 001110000 => 160
}
/* Output:  -16
			-1
			400
			ff0
			160
*/

//13.
#include <stdio.h>
int main() {
    printf("%d\n",1<<4>>4); // 0001 << 4 => 10000 >> 4 => 0001 => 1
	printf("%d\n",1<<31>>30); // 1000...000 => 1111...110 => -2
}
/* Output: 1
	 	   -2
*/

//14.
#include<stdio.h>
int main()
{
	double f=33.3; int x;
	x = (f>33.3) + (f==33.3); // 0 + 1 = 1
	printf("%d",x);
}
/* Output: 1 */

//15.
#include<stdio.h>
int main()
{
	unsigned int res;
	res = (64>>(2+1-2)) & (~(1<<2)); // 64>>1 & ~100 = 100000 & 111011  => 100000  
	printf("%d",res);
}
/* Output: 32 */

//16.
#include<stdio.h>
int main()
{
	int z,x=5,y=-10,a=4,b=2;
	z=x++ - --y * --b/a; // 5 - (-11) * 1 / 4 => 5 + 11 / 4 => 5 + 2 => 7
	printf("%d\n",z);
}
/* Output: 7 */

//17. 
#include<stdio.h>
int main()
{
	printf("%d\n",(0x11>11)&&(11>011)); // (00010001 > 11) && (11 > 000001001) => (17 > 11) && (11 > 9) => 1 && 1 => 1
	printf("%d\n",sizeof(-1)>10); // 4 > 10 => 0
	printf("%d\n",23.0>23); // 0
}
/* Output: 1
	 	   0	
	 	   0
*/

//18.
#include<stdio.h>
int main()
{
	int a=-1, b=0, c=5;
	char ch='a';	
	printf("%d\n",(ch>=97)&&(ch<=122)); // 1
	printf("%d\n",(a==0)||(b==0)||(c==0)); // 1
	printf("%d\n",(a<b)&&(b<c)); // 1
}
/* Output: 1
	 	   1	
	 	   1
*/

//19.
#include<stdio.h>
int main()
{
	printf("%d\n",-1 & 4456); // 11111...111 & ... => 4456
	printf("%d\n",-1 | 756); // 11111...111 | ... => -1
	printf("%d\n",-1 ^ 789); // 111111111111 ^ 001100010101 => 110011101010 => -2048+1024+128+64+32+8+2 => -2048 + 1258 => -790
	printf("%d\n",0 & 789); // 0 
	printf("%d\n",0 & 234); // 0
}
/* Output:  4456
			-1
			-790
			0
			0
*/

//20.
#include<stdio.h>
int main()
{
	int bitMask=1;
	printf("%d\n",60 & bitMask); // 111100 & 0000001 => 0000000 => 0
	bitMask=32;
	printf("%d\n",60 & bitMask); // 111100 & 100000 => 100000 => 32 
	printf("%d\n",70 & bitMask); // 1000110 & 0100000 => 0000000 => 0
	bitMask=512; 
	printf("%d\n",525 & bitMask); // 1000001101 & 1000000000 => 1000000000 => 512
}
/* Output:  0
			32
			0
			512
*/

//21.
#include<stdio.h>
int main()
{
	int var=50,bit=3;
	printf("%d\n",var & (1<<4)); // 0110010 & 010000 => 010000 => 16 
	printf("%d\n",var & (1<<5)); // 0110010 & 100000 => 100000 => 32
	printf("%d\n",var & (1<<6)); // 0110010 & 1000000 => 0000000 => 0 
}
/* Output:  16
			32
			0
*/

//22.
#include<stdio.h>
int main()
{
	int a=2,b=5,c=6;
	a+=b*=c=10; // c=10; b=b*c; a=a+b => b = 5*10 = 50, a = 2 + 50 = 52
	printf("%d %d %d\n",a,b,c);// 52 50 10
}
/* Output:  52 50 10 */

/*23. Program to calculate an employee's total salary based on hours worked in a week. If the
employee works more than 40 hours, calculate overtime pay (e.g., Rs. 20 per extra hour).
Additionally, provide a bonus (e.g., Rs. 500) if hours exceed 50. (Base salary = Rs. 3000.)*/
#include<stdio.h>
int main()
{
	int baseSalary = 3000, bonus = 500, overTimePay = 20, hoursWorked, salary;
	printf("Enter number of hours worked: ");
	scanf("%d",&hoursWorked);
	if(hoursWorked <= 40)
	{
		salary = baseSalary; // If hoursWorked is less than 40
	}
	else if(hoursWorked > 40 && hoursWorked <=50)
	{
		salary = baseSalary + overTimePay * ( hoursWorked - 40 ); // If hoursWorked is more than 40, employee is paid for overtime
	}
	else if(hoursWorked > 50)
	{
		salary = baseSalary + bonus + overTimePay * ( hoursWorked - 40 ); // If hoursWorked is more than 50, employee is paid a bonus additionally. 
	}
	printf("Salary= %d", salary);
}
/* Output:  Enter number of hours worked: 26
	 	 	Salary= 3000
			Enter number of hours worked: 49
			Salary= 3180
			Enter number of hours worked: 53
			Salary= 3500 
*/

//24. Program to test if a given character is: Lowercase letter, Uppercase letter, Digit, Whitespace(space, tab, newline) (operators)
#include<stdio.h>
int main()
{
	char c;
	printf("Enter the character: ");
	scanf("%c", &c); // Reading character from user
	if(c>='a' && c<='z') // If character is between a and z
	{
		printf("The character is a lowercase letter");
	}
	else if(c>='A' && c<='Z') // If character is between A and Z
	{
		printf("The character is an uppercase letter");
	}
	else if(c>='0' && c<='9') // If character is between 0 and 9
	{
		printf("The character is a digit");
	}
	else if(c==' ' || c=='\t' || c=='\n') // If character is space, tabspace or newline
	{
		printf("The character is a whitespace");
	}
	else
	{
		printf("Invalid character");
	}
	return 0;
}
/*Output: 	Enter the character: R	
			The character is an uppercase letter
			Enter the character: u	
			The character is a lowercase letter
			Enter the character: 9
			The character is a digit
			Enter the character:  	
			The character is a whitespace
			Enter the character: 		
			The character is a whitespace
			Enter the character: 
			The character is a whitespace
			Enter the character: *
			Invalid character
*/

//25. A.
#include<stdio.h>
int main()
{
	if(70>20>10) // 70>20>10 => 1>10 => 0 
		printf("true");
	else
		printf("false");
}
/* Output:  false */

//25. B.
#include<stdio.h>
int main()
{
	int a=1,b,c,d=1,e=1,f,g=1,h;
	b=(++a)+(++a)+(--a)+(a++); // 2 + 3 + 2 + 3 = 10
	printf("b: %d\n",b);
}
/* Output:  b: 10 */
/* Explanation: Undefined Behaviour */
