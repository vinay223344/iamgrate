#include <stdio.h>
int main() {
    float a=1.2,b=200,c=15;
    printf("a=%f\nb=%f\nc=%f\n",a,b,c);
    printf("%a=%4f\n%b=%f\n%c=%4f",a,a,b,c,c);
    return 0;
}
