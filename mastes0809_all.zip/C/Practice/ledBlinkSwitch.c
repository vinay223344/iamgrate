#include<stdio.h>

void delay()
{
	int i;
	for(i=0;i<10000;i++);
}
int main()
{
	int swi;
	while(1)
	{
		scanf("%d",&swi);
		if(swi==1)
		{
			printf("Hello ");
			delay();
		}
		if(swi==2)
		{
			printf(" World");
			delay();
		}
	}
}	
