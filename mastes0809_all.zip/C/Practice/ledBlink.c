#include<stdio.h>

void delay()
{
	int i;
	for(i=0;i<10000;i++);
}
int main()
{
	while(1)
	{
		printf("Hello");
		delay();
		printf("World  ");
		delay();
	}
}	
